<?php
echo "Document Successfully Uploaded";
?>