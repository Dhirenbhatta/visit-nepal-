# VisitNepal
This website is abot collecting data about nepal visitors. It uses PHP, JavaScript, sql, HTML and CSS

This is Espically for visitnepal 2020.
